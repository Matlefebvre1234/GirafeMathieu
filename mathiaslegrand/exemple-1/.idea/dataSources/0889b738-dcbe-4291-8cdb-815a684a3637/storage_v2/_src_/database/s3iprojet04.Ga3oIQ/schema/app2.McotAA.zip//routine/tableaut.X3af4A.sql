create function tableaut(debut time without time zone, fin time without time zone, categorie integer)
    returns TABLE(time_interval time without time zone, statut_reserved boolean, locaux integer)
    language plpgsql
as
$$
declare t record;
declare i record;
BEGIN
FOR i in (SELECT id_locaux FROM locaux_categorie WHERE locaux_categorie.id_categorie = categorie) LOOP
locaux := i.id_locaux;
FOR t IN(select gs.ts::time from generate_series(current_date + debut, current_date + fin, interval '15' minute) as gs(ts)) LOOP
time_interval := t.ts;
SELECT true INTO statut_reserved FROM reservation, locaux_categorie 
	WHERE   t.ts <= reservation.heure_fin AND t.ts >= reservation.heure_debut ;
return next;
END LOOP;
END LOOP;
END;
$$;

alter function tableaut(time, time, integer) owner to s3iprojet04;

