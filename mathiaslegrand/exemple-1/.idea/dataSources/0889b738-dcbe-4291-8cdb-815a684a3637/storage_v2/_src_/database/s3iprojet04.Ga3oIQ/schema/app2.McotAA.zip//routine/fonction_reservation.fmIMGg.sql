create function fonction_reservation() returns trigger
    language plpgsql
as
$$
DECLARE qte integer:= 0;
BEGIN

	SELECT count(*) INTO qte FROM reservation WHERE date = new.date AND heure_debut < new.heure_fin AND heure_fin > new.heure_debut AND idlocals = new.idlocals AND idfaculte = new.idfaculte;

    IF qte > 0 THEN
	RAISE EXCEPTION 'Le local est deja reserve';
    END IF; 
    
    RETURN NEW;
END;
$$;

alter function fonction_reservation() owner to s3iprojet04;

