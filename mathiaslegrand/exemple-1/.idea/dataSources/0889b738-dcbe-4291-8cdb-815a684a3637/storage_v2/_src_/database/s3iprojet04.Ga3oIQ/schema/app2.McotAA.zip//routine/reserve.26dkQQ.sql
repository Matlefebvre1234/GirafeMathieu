create function reserve() returns integer
    language sql
as
$$
SELECT 1
from locals
$$;

alter function reserve() owner to s3iprojet04;

