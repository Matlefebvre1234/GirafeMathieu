create function fonction_sous_locaux() returns trigger
    language plpgsql
as
$$
DECLARE compteur integer:=0;
DECLARE idlocaux integer[];
BEGIN
SELECT count(idlocals) INTO compteur FROM locals WHERE idsous_local = new.idlocals;


IF compteur!=0 THEN
	FOR i in 0 .. compteur-1 LOOP
		INSERT INTO reservation VALUES(new.date, new.heure_debut, new.heure_fin, new.cip, (SELECT idlocals FROM locals WHERE idsous_local = new.idlocals LIMIT 1 OFFSET i), new.idfaculte);
	END LOOP;
END IF;
	
	RETURN NEW;
END;
$$;

alter function fonction_sous_locaux() owner to s3iprojet04;

