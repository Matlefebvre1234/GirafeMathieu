create function fonction_reservation_15min() returns trigger
    language plpgsql
as
$$
BEGIN


    IF MOD(CAST(EXTRACT(MINUTE FROM new.heure_debut) AS INT),15) != 0 OR  MOD(CAST(EXTRACT(MINUTE FROM new.heure_fin) AS INT),15) != 0 THEN
	RAISE EXCEPTION 'Les reservations se font par plages divisibles en 15 minutes';
    END IF; 
    
    RETURN NEW;
END;
$$;

alter function fonction_reservation_15min() owner to s3iprojet04;

