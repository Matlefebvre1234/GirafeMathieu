create function comptercellule() returns trigger
    language plpgsql
as
$$
DECLARE compteur integer;
DECLARE nbMinutes integer;
BEGIN
	nbMinutes = CAST(EXTRACT(MINUTE FROM new.heure_fin) AS INT) - CAST(EXTRACT(MINUTE FROM new.heure_debut) AS INT);
	compteur = nbMinutes/15;
	UPDATE reservation SET qte_cellule = compteur WHERE idreservation = new.idreservation;
	RETURN NEW;
END;
$$;

alter function comptercellule() owner to s3iprojet04;

