create function tableau(heuredebut timestamp without time zone, heurefin timestamp without time zone, categori integer)
    returns TABLE(dates date, heure_debut time without time zone, heure_fin time without time zone, cip character, locals character varying, qte_cellule integer, categori integer)
    language sql
as
$$
SELECT date,heure_debut,heure_fin,cip,CONCAT(reservation.idlocals,'-',reservation.idFaculte),qte_cellule,locals.idfonction FROM reservation JOIN locals ON reservation.idlocals = locals.idlocals
			 WHERE date = heureDebut::date AND heureDebut::TIME <= heure_debut AND heureFIN::TIME >= heure_fin AND locals.idfonction = categori;
$$;

alter function tableau(timestamp, timestamp, integer) owner to s3iprojet04;

