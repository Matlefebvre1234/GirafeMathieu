create function log_reservation_delete() returns trigger
    language plpgsql
as
$$
Begin
INSERT INTO journalevenement(type_trigger,table_invoquer,nouveau,ancien,time)
VALUES(TG_OP,TG_TABLE_NAME,(SELECT idreservation from reservation WHERE idreservation = OLD.idreservation),OLD.idreservation,current_timestamp);
return NEW;
END;
$$;

alter function log_reservation_delete() owner to s3iprojet04;

