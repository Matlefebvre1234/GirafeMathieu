create function log_reservation_insert() returns trigger
    language plpgsql
as
$$
Begin
INSERT INTO journalevenement(type_trigger,table_invoquer,nouveau,ancien,time)
VALUES(TG_OP,TG_TABLE_NAME,NEW.idreservation,'null',current_timestamp);
RETURN NEW;
END;
$$;

alter function log_reservation_insert() owner to s3iprojet04;

